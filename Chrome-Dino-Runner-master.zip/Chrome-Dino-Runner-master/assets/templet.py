from keras.models import load_model
from PIL import ImageGrab
import cv2
import cv2 as cv
import keyboard
import numpy as np
model = load_model('dino.h5')

template1 = cv.imread('images/1_tree_big_1.png', 0)
template2 = cv.imread('images/1_tree_little_1.png', 0)
template3 = cv.imread('images/1_Bird_Down.png', 0)
template4 = cv.imread('images/1_Bird_Up.png', 0)
for i in range(1, 5):
    locals()["w" + str(i)], locals()["h" + str(i)] = locals()["template" + str(i)].shape[::-1]
def process_img(original_image):

        img_gray = cv2.cvtColor(original_image, cv2.COLOR_BGR2GRAY)

        return img_gray
while(True):
        data = [0, 0, 0, 0, 0, 0, 0]
        Input =[0, 0, 0, 0, 0, 0]

        screen =  np.array(ImageGrab.grab(bbox=(0, 0, 800, 800)))
        img_gray = process_img(screen)

        for i in range(1, 5):
            locals()["res" + str(i)] = cv.matchTemplate(img_gray, locals()["template" + str(i)], cv.TM_CCOEFF_NORMED)
    
        threshold = 0.8
        for i in range(1, 5):
            locals()["loc" + str(i)] = np.where(locals()["res" + str(i)] >= threshold)


        for pt in zip(*loc1[::-1]):
                cv.rectangle(img_gray, pt, (pt[0] + w1, pt[1] + h1), (0, 0, 255), 2)
                data[0] = pt[0]
                break

        for pt in zip(*loc2[::-1]):
                cv.rectangle(img_gray, pt, (pt[0] + w2, pt[1] + h2), (0, 0, 255), 2)
                data[1] = pt[0]
                break

        for pt in zip(*loc3[::-1]):
                cv.rectangle(img_gray, pt, (pt[0] + w3, pt[1] + h3), (0, 0, 255), 2)
                data[2] = pt[0]
                data[3] = pt[1]
                break

        for pt in zip(*loc4[::-1]):
                cv.rectangle(img_gray, pt, (pt[0] + w4, pt[1] + h4), (0, 0, 255), 2)
                data[4] = pt[0]
                data[5] = pt[1]
                break

        Input[0] = data[0]
        Input[1] = data[1]
        Input[2] = data[2]
        Input[3] = data[3]
        Input[4] = data[4]
        Input[5] = data[5]

        result = model.predict(np.expand_dims(Input, axis=0))

        if result > 0.223:
            keyboard.press('up')
        else:
            keyboard.release('up')
    
        cv2.imshow('window', img_gray)
        if cv2.waitKey(25) & 0xFF == ord('q'):
            cv2.destroyAllWindows()
            break